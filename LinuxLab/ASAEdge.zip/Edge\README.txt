ASA Edge Manual Deployment Package

Directory structure:
-	/core
This folder contains the core modules for Azure Stream Analytics on edge devices and will not change from query to query. However, Microsoft may update the packages from time to time
o	asa.js, is the initialization module for streaming data processing. It receives input events from the gateway message bus and sends output events also to message bus. In addition to data from the message bus, it can use reference data from local disk. 
o	TStreamsMain, is the streaming data processing Runtime. It needs to be copied into the folder with other node JS modules.
o	package.json, contains project metadata and dependencies.
-	/src
This folder contains all the user defined resources needed for running the ASA job:
o	Compiledquery.txt, compiled and serialized query � generated for you
o	UDFfunction.txt, user defined javascript functions � generated for you
o	ReferenceData.txt, reference data paths � generated for you
o	Gateway.json, used to set module configuration, you could add or delete module, edit arguments for a module, edit message routes in gateway.json. This one may need to be edited depending of your gateway configuration.

Steps to run ASA module:
	a.  Install or deploy the Azure IoT Gateway SDK sample with node JS modules 
	b.	Extract files from the zip containing your ASA package
	c.	copy asa.js to the modules folder, <azure_iot_gateway_sdk_root>\js\modules
	d.	merge content of package.json: only need to merge dependencies
	e.	merge content of gateway.json to gw.cloud.config.json
		I.	add the node_asa module declaration. Use the one provided in the gateway.json  
		II.	Add node_asa into route between sensor and iothub
		III. Configure your IoT Hub device connection string in gw.cloud.config.json 
	f.	Copy TstreamsMain folder to node_modules folder, <azure_iot_gateway_sdk_root>\js\node_modules
	g.	Create a new folder <azure_iot_gateway_sdk_root>\js\src
	h.	Copy files from src folder to the newly created src folder (compiledquery.txt, ReferenceData.txt and UDFfunction.txt, the last two are optional, depending of your query)
	i.	Rebuild project
		cd <azure_iot_gateway_sdk_root>\js  
		npm install  
	j.	Run the gateway
		npm run cloud 

Input format
	Stream and reference data needs to be in JSON format, and formatted according to the following schema.
	Message content:
		Input data need to contain the following top-level artifacts:
			-	"name" string: this is the name used as your input in ASA job.
			-	"content" array: array of objects containing the data to be processed. In ASA, it will be used as table columns and value for each column.
		Message meta-data:
			-	�Source�: �sensor� � friendly name on the source, not used by ASA.
			-	�Name�: �data� � do not change, ASA module expects to see this name.
	Example of JavaScript code to produce this meta-data:
		this.messageBus.publish({
			properties: {
               'source': 'sensor',
               'name' : 'data'
              },
			content: new Uint8Array(Buffer.from(jsonContent))
		});
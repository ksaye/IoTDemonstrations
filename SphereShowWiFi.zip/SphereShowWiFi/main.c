﻿#include <errno.h>				// added to the Blank application  -- Kevin Saye
#include <signal.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

// applibs_versions.h defines the API struct versions to use for applibs APIs.
#include "applibs_versions.h"
#include <applibs/log.h>
#include <applibs/gpio.h>		// added to the Blank application  -- Kevin Saye
#include <applibs/wificonfig.h>	// added to the Blank application  -- Kevin Saye

								// also set the "WifiConfig": true in the app_manifest.json

#include "mt3620_rdb.h"

// This C application for the MT3620 Reference Development Board (Azure Sphere)
// outputs a string every second to Visual Studio's Device Output window
//
// It uses the API for the following Azure Sphere application libraries:
// - log (messages shown in Visual Studio's Device Output window during debugging)

static volatile sig_atomic_t terminationRequested = false;

/// <summary>
///     Signal handler for termination requests. This handler must be async-signal-safe.
/// </summary>
static void TerminationHandler(int signalNumber)
{
    // Don't use Log_Debug here, as it is not guaranteed to be async signal safe
    terminationRequested = true;
}

/// <summary>
///     Trigger a WiFi scan and list found WiFi networks.
///		From the Azure IoT Hub Sample
///		added to the Blank application  -- Kevin Saye
/// </summary>
static void DebugPrintScanFoundNetworks(void)
{
	int result = WifiConfig_TriggerScanAndGetScannedNetworkCount();
	if (result < 0) {
		Log_Debug(
			"ERROR: WifiConfig_TriggerScanAndGetScannedNetworkCount failed to get scanned "
			"network count with result %d. Errno: %s (%d).\n",
			result, strerror(errno), errno);
	}
	else if (result == 0) {
		Log_Debug("INFO: Scan found no WiFi network.\n");
	}
	else {
		size_t networkCount = (size_t)result;
		Log_Debug("INFO: Scan found %d WiFi networks:\n", result);
		WifiConfig_ScannedNetwork *networks =
			(WifiConfig_ScannedNetwork *)malloc(sizeof(WifiConfig_ScannedNetwork) * networkCount);
		result = WifiConfig_GetScannedNetworks(networks, networkCount);
		if (result < 0) {
			Log_Debug(
				"ERROR: WifiConfig_GetScannedNetworks failed to get scanned networks with "
				"result %d. Errno: %s (%d).\n",
				result, strerror(errno), errno);
		}
		else {
			// Log SSID, signal strength and frequency of the found WiFi networks
			networkCount = (size_t)result;
			for (size_t i = 0; i < networkCount; ++i) {
				Log_Debug("INFO: %3d) SSID \"%.*s\", Signal Level %d, Frequency %dMHz\n", i,
					networks[i].ssidLength, networks[i].ssid, networks[i].signalRssi,
					networks[i].frequencyMHz);
			}
		}
		free(networks);
	}
}

/// <summary>
///     Main entry point for this sample.
/// </summary>
int main(int argc, char *argv[])
{
    Log_Debug("Application starting\n");

    // Register a SIGTERM handler for termination requests
    struct sigaction action;
    memset(&action, 0, sizeof(struct sigaction));
    action.sa_handler = TerminationHandler;
    sigaction(SIGTERM, &action, NULL);

    // Main loop
    const struct timespec sleepTime = {1, 0};
    while (!terminationRequested) {
		DebugPrintScanFoundNetworks();		// added to the Blank application  -- Kevin Saye
        nanosleep(&sleepTime, NULL);
    }

    Log_Debug("Application exiting\n");
    return 0;
}

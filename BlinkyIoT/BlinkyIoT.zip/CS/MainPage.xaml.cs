﻿// Copyright (c) Microsoft. All rights reserved.

using System;
using Windows.Devices.Gpio;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Media;
using System.Threading.Tasks;
using Microsoft.Azure.Devices.Client;
using System.Text;

namespace Blinky
{
    public sealed partial class MainPage : Page
    {
        private const int LED_PIN = 5;
        private GpioPin pin;
        private GpioPinValue pinValue;
        private DispatcherTimer timer;
        private SolidColorBrush redBrush = new SolidColorBrush(Windows.UI.Colors.Red);
        private SolidColorBrush grayBrush = new SolidColorBrush(Windows.UI.Colors.LightGray);
        static string IoTDeviceConnectionString = "{Your Connection String Here}";
        static DeviceClient deviceClient;

        public MainPage()
        {
            InitializeComponent();
            connectToIoTHub();
            receiveMessage();

            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromMilliseconds(500);
            timer.Tick += Timer_Tick;
            InitGPIO();
            if (pin != null)
            {
                timer.Start();
            }        
        }

        private void InitGPIO()
        {
            var gpio = GpioController.GetDefault();

            // Show an error if there is no GPIO controller
            if (gpio == null)
            {
                pin = null;
                GpioStatus.Text = "There is no GPIO controller on this device.";
                return;
            }

            pin = gpio.OpenPin(LED_PIN);
            pinValue = GpioPinValue.High;
            pin.Write(pinValue);
            pin.SetDriveMode(GpioPinDriveMode.Output);

            GpioStatus.Text = "GPIO pin initialized correctly.";

        }

        private void Timer_Tick(object sender, object e)
        {
            if (pinValue == GpioPinValue.High)
            {
                pinValue = GpioPinValue.Low;
                pin.Write(pinValue);
                LED.Fill = redBrush;
            }
            else
            {
                pinValue = GpioPinValue.High;
                pin.Write(pinValue);
                LED.Fill = grayBrush;
            }
        }

        private async void connectToIoTHub()
            {
                deviceClient = DeviceClient.CreateFromConnectionString(IoTDeviceConnectionString, TransportType.Amqp);
                await deviceClient.OpenAsync();
            
                IoTSTatus.Text = "Connected to IoT Hub";
        }

        private async void receiveMessage()
        {
            while (true)
            {
                try
                {
                    Message IoTMessage = await deviceClient.ReceiveAsync(new TimeSpan(0, 0, 0, 30));
                    if (IoTMessage != null)
                    {
                        string realmessage = Encoding.ASCII.GetString(IoTMessage.GetBytes());
                        if (realmessage.Contains("interval:"))
                        {
                            timer.Stop();
                            DelayText.Text = realmessage.Substring(9) + "ms";
                            timer.Interval = TimeSpan.FromMilliseconds(Convert.ToDouble(realmessage.Substring(9)));
                            timer.Start();
                            
                        } else {
                            MyIoTMessage.Text = realmessage;
                        }
                        
                        await deviceClient.CompleteAsync(IoTMessage);
                    }
                }
                catch (Exception er)
                {
                    if (er.Message != "Cannot access a disposed object.\r\nObject name: 'The object has been closed and cannot be reopened.'.")
                    {
                        MyIoTMessage.Text = "receiveMessage Error: " + er.Message.ToString();
                    }
                }
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Azure.Devices;

namespace DoverIDT
{

    public partial class Form1 : Form
    {

        static ServiceClient serviceClient;
        static string iotHubConnectionString = "removed";

        public Form1()
        {
            serviceClient = ServiceClient.CreateFromConnectionString(iotHubConnectionString);
            InitializeComponent();
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            // create a method with response 5 seconds and connection 10 seconds
            CloudToDeviceMethod C2Dmethod = new CloudToDeviceMethod("test", new TimeSpan(0, 0, 10), new TimeSpan(0, 0, 10));
            C2Dmethod.SetPayloadJson("{ \"message\":\"hello\", \"machineName\":\"leaf1\", \"parser\":\"parser\"}");

            // call the method
            CloudToDeviceMethodResult myresult = await serviceClient.InvokeDeviceMethodAsync("Gateway1", "DIDT", C2Dmethod);

            // we do nothing with the results, but we could!
            string resultJson = myresult.GetPayloadAsJson();
            //m(resultJson);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            var addDevice = new AddDevice();
            addDevice.Closed += (s, args) => this.Show();
            addDevice.Show();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            webBrowser1.Navigate("https://msit.powerbi.com/view?r=eyJrIjoiODZiMWUyZDgtNWI5Zi00ZTdlLTgwMmEtMTA1NjE5NWVkOTYwIiwidCI6IjcyZjk4OGJmLTg2ZjEtNDFhZi05MWFiLTJkN2NkMDExZGI0NyIsImMiOjV9");
            webBrowser2.Navigate("https://msit.powerbi.com/view?r=eyJrIjoiNTEwOGVmYjYtMmRjOS00OGMwLTgzODctZTY4ZjU4NGQ0YTIxIiwidCI6IjcyZjk4OGJmLTg2ZjEtNDFhZi05MWFiLTJkN2NkMDExZGI0NyIsImMiOjV9");
        }
    }
}

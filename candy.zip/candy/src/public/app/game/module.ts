/// <reference path='../../../../typings/angularjs/angular.d.ts' />

module GameApp {
	'use strict';
	
	angular.module('GameApp',[]);
}
/// <reference path='_references.ts' />
module App{
	'use strict';
	
	
	angular.module('App', ['App.Admin']);
	
}
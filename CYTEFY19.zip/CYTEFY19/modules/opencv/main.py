# Copyright (c) Microsoft. All rights reserved.
# Licensed under the MIT license. See LICENSE file in the project root for
# full license information.

#pylint: disable=E0401,E0611,E1101

# i think I am getting failures to connect to edgeHub because wrong version of azure-iothub-device-client, yet if I try
# 1.4.0, I get lib boost not found errors.  trying to build the iotclient from scratch to verify.

import os
import random
import datetime
import time
import sys
import iothub_client
import json
import cv2
import base64
import SimpleHTTPServer
import SocketServer
import thread
import socket
import commands

from scipy.linalg import norm
from scipy import sum, average

from iothub_client import IoTHubModuleClient, IoTHubClientError, IoTHubTransportProvider
from iothub_client import IoTHubMessage, IoTHubMessageDispositionResult, IoTHubError

# messageTimeout - the maximum time in milliseconds until a message times out.
# The timeout period starts at IoTHubModuleClient.send_event_async.
# By default, messages do not expire.
MESSAGE_TIMEOUT = 10000

# global counters
RECEIVE_CALLBACKS = 0
SEND_CALLBACKS = 0
TWIN_CALLBACKS = 0
SEND_MESSAGECOUNTER = 0
SEND_REPORTED_STATE_CALLBACKS = 0

# Choose HTTP, AMQP or MQTT as transport protocol.  Currently only MQTT is supported.
PROTOCOL = IoTHubTransportProvider.MQTT

# Web Service port
WebServicePort = 8080

# how long we keep older files in seconds
keepImageFiles = 1200   # twenty minutes

# camera JSON, updated from the desired properties
cameraURL = "rtsp://184.72.239.149/vod/mp4:BigBuckBunny_175k.mov"
#cameraURL = "https://mediusprod.streaming.mediaservices.windows.net/eba2dea0-68ce-4c77-93df-7d44e5220052/116183_IGNITE2018_Keynote_v2_500.ism/manifest"

# a bool value used if we add or remove a camera from the TWIN
cameraURLChanged = True

# Default imageProcessing interval in seconds
imageProcessingInterval = 70

# when we last procesed an image
lastProcessed = time.time()

# Weather or not we conver the images to Gray Scale to eliminate color issues
imageToGrayScale = False

# Weather or not we normalize the images, for different sizes and etc
imageNormalization = False

# Callback received when the message that we're forwarding is processed.
def send_confirmation_callback(message, result, user_context):
    global SEND_CALLBACKS
    print ( "Confirmation[%d] received for message with result = %s" % (user_context, result) )
#    map_properties = message.properties()
#    key_value_pair = map_properties.get_internals()
#    print ( "    Properties: %s" % key_value_pair )
    SEND_CALLBACKS += 1
#    print ( "    Total calls confirmed: %d" % SEND_CALLBACKS )

# device_twin_callback is invoked when twin's desired properties are updated.
def module_twin_callback(update_state, payload, user_context):
    global TWIN_CALLBACKS
    global cameraURL
    global imageProcessingInterval
    global imageToGrayScale
    global imageNormalization
    global cameraURLChanged

    print ( "\nTwin callback called with:\nupdateStatus = %s\npayload = %s\n" % (update_state, payload) )
    data = json.loads(payload)
    # for full TWIN messages
    if "desired" in data and "imageNormalization" in data["desired"]:
        imageNormalization = data["desired"]["imageNormalization"]
    if "desired" in data  and "imageToGrayScale" in data["desired"]:
        imageToGrayScale = data["desired"]["imageToGrayScale"]
    if "desired" in data and "cameraURL" in data["desired"]:
        cameraURL = data["desired"]["cameraURL"]
        print ( "  camera URL: ", cameraURL )
    if "desired" in data and "imageProcessingInterval" in data["desired"]:
        imageProcessingInterval = data["desired"]["imageProcessingInterval"]
        print ( "  Image processing interval is: %d\n" % imageProcessingInterval )

    # for partial TWIN message
    if "imageNormalization" in data:
        imageNormalization = data["imageNormalization"]
    if "imageToGrayScale" in data:
        imageToGrayScale = data["imageToGrayScale"]
    if "cameraURL" in data:
        cameraURL= data["cameraURL"]
        print ( "  New camera URL: ", cameraURL)
    if "imageProcessingInterval" in data:
        imageProcessingInterval = data["imageProcessingInterval"]
        print ( "  New image processing interval is: %d\n" % imageProcessingInterval )

    TWIN_CALLBACKS += 1
    cameraURLChanged = True
    print ( "Total calls confirmed: %d\n" % TWIN_CALLBACKS )

# receive_message_callback is invoked when an incoming message arrives on the specified 
# input queue (in the case of this sample, "input1").  Because this is a filter module, 
# we will forward this message onto the "output1" queue.
def receive_message_callback(message, hubManager):
    global RECEIVE_CALLBACKS
    message_buffer = message.get_bytearray()
    size = len(message_buffer)
    print ( "    Data: <<<%s>>> & Size=%d" % (message_buffer[:size].decode('utf-8'), size) )
    map_properties = message.properties()
    key_value_pair = map_properties.get_internals()
    print ( "    Properties: %s" % key_value_pair )
    RECEIVE_CALLBACKS += 1
    print ( "    Total calls received: %d" % RECEIVE_CALLBACKS )
    hubManager.forward_event_to_output("output1", message, 0)
    return IoTHubMessageDispositionResult.ACCEPTED

def send_reported_state_callback(status_code, user_context):
    global SEND_REPORTED_STATE_CALLBACKS
    print ( "Confirmation for reported state received with:\nstatus_code = [%d]\ncontext = %s" % (status_code, user_context) )
    SEND_REPORTED_STATE_CALLBACKS += 1
    print ( "    Total calls confirmed: %d" % SEND_REPORTED_STATE_CALLBACKS )

def to_grayscale(arr):
    "If arr is a color image (3D array), convert it to grayscale (2D array)."
    if len(arr.shape) == 3:
        return average(arr, -1)  # average over the last axis (color channels)
    else:
        return arr

def normalize(arr):
    rng = arr.max()-arr.min()
    amin = arr.min()
    return (arr-amin)*255/rng

def compare_images(img1, img2):
    try:
        # normalize to compensate for exposure difference
        if imageNormalization:
            img1 = normalize(img1)
            img2 = normalize(img2)
        
        # calculate the difference and its norms
        diff = img1 - img2  # elementwise for scipy arrays
        m_norm = sum(abs(diff))  # Manhattan norm
        z_norm = norm(diff.ravel(), 0)  # Zero norm
        return (m_norm, z_norm)
    except:
        return (0.0, 0.0)

def startWebService():
    Handler = SimpleHTTPServer.SimpleHTTPRequestHandler
    httpd = SocketServer.TCPServer(("", WebServicePort), Handler)

    print ( "Listening for remote connections on port: ", WebServicePort)
    httpd.serve_forever()

class HubManager(object):

    def __init__(
            self,
            protocol=IoTHubTransportProvider.MQTT):
        self.client_protocol = protocol
        self.client = IoTHubModuleClient()
        self.client.create_from_environment(protocol)

        # set the time until a message times out
        self.client.set_option("messageTimeout", MESSAGE_TIMEOUT)
        
        # sets the callback when a message arrives on "input1" queue.  Messages sent to 
        # other inputs or to the default will be silently discarded.
        #self.client.set_message_callback("input1", receive_message_callback, self)
        self.client.set_module_twin_callback(module_twin_callback, self)

        # start the background web service
        thread.start_new_thread(startWebService, ())

    # Forwards the message received onto the next stage in the process.
    def forward_event_to_output(self, outputQueueName, event, send_context):
        self.client.send_event_async(
            outputQueueName, event, send_confirmation_callback, send_context)
    
    def send_reported_state(self, reported_state, size, send_context):
        self.client.send_reported_state(
            reported_state, size, send_reported_state_callback, send_context)

def removeOldFiles():
    for f in os.listdir("."):
        if "-image.jpg" in f:
            fullpath = os.path.join(".", f)
            if os.stat(fullpath).st_mtime < (time.time() - keepImageFiles):
                if os.path.isfile(fullpath):
                    os.remove(fullpath)

def main(protocol):
    global SEND_MESSAGECOUNTER
    global cameraURLChanged
    global cameraURL
    global lastProcessed
    global hub_manager

    priorImage = None

    try:
        print ( "\nPython %s\n" % sys.version )
        print ( "IoT Hub Client for Python" )
        print ( "video mounted: ", commands.getstatusoutput('mount | grep video'))

        myIP = socket.gethostbyname(socket.gethostname())

        print (" now processing from: ", cameraURL)
        ovc = cv2.VideoCapture(cameraURL)
        cameraURLChanged = False

        reported_stateJSON = {}
        reported_stateJSON["imageProcessingInterval"] = imageProcessingInterval
        reported_stateJSON["cameraURL"] = cameraURL
        reported_stateJSON["imageToGrayScale"] = imageToGrayScale
        reported_stateJSON["imageNormalization"] = imageNormalization
        reported_state = json.dumps(reported_stateJSON)
        hub_manager.send_reported_state(reported_state, len(reported_state), SEND_REPORTED_STATE_CALLBACKS)

        while True: # while loop
            if cameraURLChanged:
                cameraURLChanged = False
                return

            frame = ovc.read()[1]

            # because we are processing a stream, we only pull an image on the imageProcessingInterval
            if lastProcessed + imageProcessingInterval < time.time():
                lastProcessed = time.time()
                # removing old files
                removeOldFiles()

                start = datetime.datetime.now()
                filename = str(time.strftime('%Y-%m-%d-%H-%M-%S') +'-image.jpg')
                cv2.imwrite("current.jpg", frame)

                if priorImage is None:
                    # we don't have a prior image, must be the first time we saw this camera or TWIN change
                    ManhattanImageChange = 0.0
                    ZeroImageChange = 0.0

                    # naming and writing the image file
                    cv2.imwrite(filename, frame)
                    priorImage = frame
                else:
                    if imageToGrayScale:
                        img1 = to_grayscale(priorImage.astype(float))
                        img2 = to_grayscale(frame.astype(float))
                    else:
                        img1 = priorImage.astype(float)
                        img2 = frame.astype(float)                   
                    
                    n_m, n_0 = compare_images(img1, img2)
                    ManhattanImageChange = n_0*1.0/frame.size
                    ZeroImageChange = n_m*1.0/frame.size

                    # naming and writing the image file
                    cv2.imwrite(filename, frame)
                    priorImage = frame
            
                if os.path.getsize(filename) == 0:
                    # the image file size should never be 0, restart the openCV
                    return
                else:
                    # Starring our message
                    IoTMessageJSON = {}
                    processingTime = datetime.datetime.now() - start
                    IoTMessageJSON['OpenCVProcessingTimeMS'] = processingTime.total_seconds() * 1000
                    IoTMessageJSON['ManhattanImageChange'] = ManhattanImageChange 
                    IoTMessageJSON['imageFileName'] = filename
                    IoTMessageJSON['imageURL'] = str("http://" + myIP + ":" + str(WebServicePort) + "/" + filename)
                    IoTMessageJSON['ZeroImageChange'] = ZeroImageChange
                    IoTMessageJSON['imageSize'] = os.path.getsize(filename)
                    IoTMessageJSON['cameraURL'] = cameraURL
                    IoTMessageJSON['dateTime'] = time.strftime('%Y-%m-%dT%H:%M:%S')
                    IoTMessage = IoTHubMessage(bytearray(json.dumps(IoTMessageJSON), 'utf8'))
                    hub_manager.forward_event_to_output("output1", IoTMessage, SEND_MESSAGECOUNTER)
                    print ("sent: [", SEND_MESSAGECOUNTER, "] ", json.dumps(IoTMessageJSON))
                    SEND_MESSAGECOUNTER += 1

            # end of 'lastProcessed + imageProcessingInterval < time.time()' loop
        # end of while loop
        ovc.release()

    except IoTHubError as iothub_error:
        print ( "Unexpected error %s from IoTHub" % iothub_error )
        return
    except:
        print ( "IoTHubClient stopped" )

if __name__ == '__main__':
    hub_manager = HubManager(PROTOCOL)
    while True:
        main(PROTOCOL)